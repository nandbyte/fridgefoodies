module.exports = {
  jwtSecret: process.env.JWT_SECRET || '0c20801f-67fb-4808-8c31-d06d96104aaa'
};