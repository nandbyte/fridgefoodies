import styled from 'styled-components';

const Img = styled.img`
  max-height: 77px;
`;

export default Img;
