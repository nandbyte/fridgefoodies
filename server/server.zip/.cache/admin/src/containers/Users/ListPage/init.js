const init = initialState => initialState;

export default init;
