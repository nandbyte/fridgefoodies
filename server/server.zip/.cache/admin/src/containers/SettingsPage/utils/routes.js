import customRoutes from 'ee_else_ce/containers/SettingsPage/utils/customRoutes';
import defaultRoutes from './defaultRoutes';

export default [...customRoutes, ...defaultRoutes];
