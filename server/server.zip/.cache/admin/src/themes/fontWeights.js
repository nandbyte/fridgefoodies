const fontWeights = {
  regular: 400,
  semiBold: 500,
  bold: 600,
  black: 900,
};

export default fontWeights;
